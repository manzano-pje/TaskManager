#!/bin/bash
# Script para instalar Foundry no Windows

# Criar diretório
mkdir -p ~/.foundry/bin

# Baixar binários mais recentes
FOUNDRY_VERSION="nightly"
BASE_URL="https://github.com/foundry-rs/foundry/releases/download/${FOUNDRY_VERSION}"

# Baixar cada ferramenta
echo "Baixando forge..."
curl -L "${BASE_URL}/forge-${FOUNDRY_VERSION}-x86_64-pc-windows-msvc.exe" -o ~/.foundry/bin/forge.exe

echo "Baixando cast..."
curl -L "${BASE_URL}/cast-${FOUNDRY_VERSION}-x86_64-pc-windows-msvc.exe" -o ~/.foundry/bin/cast.exe

echo "Baixando anvil..."
curl -L "${BASE_URL}/anvil-${FOUNDRY_VERSION}-x86_64-pc-windows-msvc.exe" -o ~/.foundry/bin/anvil.exe

echo "Baixando chisel..."
curl -L "${BASE_URL}/chisel-${FOUNDRY_VERSION}-x86_64-pc-windows-msvc.exe" -o ~/.foundry/bin/chisel.exe

# Adicionar ao PATH
echo 'export PATH="$HOME/.foundry/bin:$PATH"' >> ~/.bashrc

# Recarregar
source ~/.bashrc

echo "Foundry instalado! Teste com: forge --version"
