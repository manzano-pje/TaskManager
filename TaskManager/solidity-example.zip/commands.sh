# Dentro da pasta web3, remover arquivos exemplo
rm src/Counter.sol
rm test/Counter.t.sol  
rm script/Counter.s.sol

# Criar nossos arquivos
touch src/TodoContract.sol
touch test/TodoContract.t.sol
touch script/Deploy.s.sol
