# PowerShell script para instalar Foundry
# Execute como Administrador

# Criar diretório
$foundryDir = "$env:USERPROFILE\.foundry\bin"
New-Item -ItemType Directory -Force -Path $foundryDir

# URL base
$baseUrl = "https://github.com/foundry-rs/foundry/releases/download/nightly"

# Baixar binários
Write-Host "Baixando Foundry..."

Invoke-WebRequest -Uri "$baseUrl/forge-nightly-x86_64-pc-windows-msvc.exe" -OutFile "$foundryDir\forge.exe"
Invoke-WebRequest -Uri "$baseUrl/cast-nightly-x86_64-pc-windows-msvc.exe" -OutFile "$foundryDir\cast.exe"
Invoke-WebRequest -Uri "$baseUrl/anvil-nightly-x86_64-pc-windows-msvc.exe" -OutFile "$foundryDir\anvil.exe"
Invoke-WebRequest -Uri "$baseUrl/chisel-nightly-x86_64-pc-windows-msvc.exe" -OutFile "$foundryDir\chisel.exe"

# Adicionar ao PATH
$currentPath = [Environment]::GetEnvironmentVariable("PATH", "User")
if ($currentPath -notlike "*$foundryDir*") {
    [Environment]::SetEnvironmentVariable("PATH", "$currentPath;$foundryDir", "User")
    Write-Host "Adicionado ao PATH. Reinicie o terminal."
}

Write-Host "Foundry instalado em: $foundryDir"
Write-Host "Teste com: forge --version"
